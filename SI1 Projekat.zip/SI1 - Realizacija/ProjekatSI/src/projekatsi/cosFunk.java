package projekatsi;

import static java.lang.Math.cos;
import java.util.InputMismatchException;
import java.util.Scanner;

public class cosFunk {

    private final float[] cosY = new float[5000];
    private int proveraCos = 0;
    
    public cosFunk(){
        Scanner scan = new Scanner(System.in);
        int[] kCos;
        double[] aCos;
        int brCos = 0;
        int i,j; 
        
        System.out.println("\nUnesite broj kosinusnih funkcija:");
        try {
             brCos = scan.nextInt();
             kCos = new int[brCos];
             aCos = new double[brCos];
        
        for(i=0;i<brCos;i++){
        System.out.println("\nUnesite koeficijent za " + (i+1) 
                +". kosinusnu funkciju:");
        kCos[i] = scan.nextInt();
        System.out.println("\nUnesite argument za " + (i+1) 
                +". kosinusnu funkciju:");
        aCos[i] = scan.nextDouble();}
        
        for(i=0;i<5000;i++){
            float sum2 = 0;
            for(j=0;j<brCos;j++){
            sum2 = sum2 + (float) (kCos[j]*cos(Math.toRadians(aCos[j])*0.01*i));}
            this.cosY[i]=sum2;}
         }
         catch (InputMismatchException e) {
            this.proveraCos = 1;
            System.err.println("Lose ste uneli parametar!");
         }
    }
    
    public float[] getCosY() {
    return this.cosY;
     }
    
    public int getProveraCos() {
    return this.proveraCos;
    }
 }