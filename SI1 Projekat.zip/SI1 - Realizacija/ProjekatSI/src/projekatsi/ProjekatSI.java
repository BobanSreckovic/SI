package projekatsi;

import java.util.Scanner;
import org.jfree.ui.RefineryUtilities;

public class ProjekatSI {
    
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        float[] funkY = new float[5000];
        float[] funkX = new float[5000];
        int i;
        System.err.println("Kao unos za trazene parametre - "
                + "broj funkcija i koeficijenti funkcija "
                + "unosite cele brojeve!");
        System.err.println("Kao unos za trazene parametre - "
                + "argumenti funkcija "
                + "unosite decimalne brojeve!");
        System.err.println("");
        
        try {
        Thread.sleep(100);
        } catch (InterruptedException ex) {
        }
        
        sinFunk s1 = new sinFunk();
        
        try {
        Thread.sleep(100);
        } catch (InterruptedException ex) {
        }
        
        cosFunk s2 = new cosFunk();
        
        float[] esinY = s1.getSinY();
        float[] ecosY = s2.getCosY();
        
        for(i=0;i<5000;i++){
            funkY[i]=esinY[i]+ecosY[i];
            funkX[i]=(float) (i*0.01);
        }
    
        int proveraSin = s1.getProveraSin();
        int proveraCos = s2.getProveraCos();
        
    if(proveraSin == 0 && proveraCos == 0){
        final chartFunk demo = new chartFunk("Grafik funkcije",funkX,funkY);
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
    }else{
    System.err.println("");    
    System.err.println("Lose ste uneli neki trazeni parametar!");
    System.err.println("Pokrenite ponovo program i obratite "
            + "paznju na unos parametara!");
    }
 }
}