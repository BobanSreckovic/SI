package projekatsi;

import static java.lang.Math.sin;
import java.util.InputMismatchException;
import java.util.Scanner;

public class sinFunk {

    private final float[] sinY = new float[5000];
    private int proveraSin = 0;
    
    public sinFunk(){
        Scanner scan = new Scanner(System.in);
        int[] kSin;
        double[] aSin; 
        int brSin = 0;
        int i,j;
        
        System.out.println("\nUnesite broj sinusnih funkcija:");
        try {
             brSin = scan.nextInt();
             kSin = new int[brSin];
             aSin = new double[brSin];
        
        for(i=0;i<brSin;i++){
        System.out.println("\nUnesite koeficijent za " + (i+1) 
                +". sinusnu funkciju:");
        kSin[i] = scan.nextInt();
        System.out.println("\nUnesite argument za " + (i+1) 
                +". sinusnu funkciju:");
        aSin[i] = scan.nextDouble();}
        
        for(i=0;i<5000;i++){
            float sum1 = 0;
            for(j=0;j<brSin;j++){
            sum1 = sum1 + (float) (kSin[j]*sin(Math.toRadians(aSin[j])*0.01*i));}
            this.sinY[i]=sum1;}
         }
         catch (InputMismatchException e) {
            this.proveraSin = 1;
            System.err.println("Lose ste uneli parametar!");
         }
    }
    
    public float[] getSinY() {
    return this.sinY;
    }
    
    public int getProveraSin() {
    return this.proveraSin;
    }
 }